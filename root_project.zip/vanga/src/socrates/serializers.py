import os

from django.core.exceptions import ObjectDoesNotExist
from django.utils.translation import gettext_lazy as _
from rest_framework import serializers

from core.models import Group
from socrates.models import Kind, Report
from socrates.validators import HGroupValidator, KindIdValidator


class HGroupIdSerializer(serializers.Field):
    def to_internal_value(self, data):
        try:
            return Group.objects.get(harvester_id=data)
        except Group.DoesNotExist:
            return None

    def to_representation(self, instance):
        return instance.harvester_id


class ReportIdSerialazer(serializers.Field):
    def to_internal_value(self, data):
        return Report.objects.get(id=data)


# class PresignedUrlQueryParamsSerializer(serializers.Serializer):
#     report = ReportIdSerialazer()


class ParamsSerializer(serializers.Serializer):
    def to_representation(self, obj):
        return obj


class KindSerializer(serializers.Serializer):

    id = serializers.IntegerField()
    name = serializers.CharField()
    short_description = serializers.CharField()
    description = serializers.CharField()
    params = ParamsSerializer()


class UserSerializer(serializers.Serializer):
    harvester_id = serializers.IntegerField()
    email = serializers.CharField()
    username = serializers.CharField()


class FileNameSerializer(serializers.Serializer):
    def to_representation(self, obj):
        try:
            file_name = os.path.basename(obj.file.name)
        except ValueError:
            file_name = ''
        return file_name


class GroupIdRelatedField(serializers.RelatedField):
    """
    A read-write field that represents the target of the relationship
    by a unique 'slug' attribute.
    """
    # @todo: translate it
    default_error_messages = {
        'does_not_exist': _('Object does not exist.'),
        'invalid': _('Invalid value.'),
        }

    def get_queryset(self):
        return Group.objects.all()

    def to_internal_value(self, data):
        queryset = self.get_queryset()
        try:
            return queryset.get(harvester_id=data)
        except ObjectDoesNotExist:
            self.fail('does_not_exist')
        except (TypeError, ValueError):
            self.fail('invalid')

    def to_representation(self, obj):
        return getattr(obj, 'harvester_id')


class ReportSerializer(serializers.ModelSerializer):
    group_id = GroupIdRelatedField(source='hgroup', read_only=True)
    user = UserSerializer()

    class Meta:
        model = Report
        exclude = ('hgroup', )


class GetReportQueryParamsSerializer(serializers.Serializer):

    start_date = serializers.DateTimeField(required=False)
    finish_date = serializers.DateTimeField(required=False)
    group_id = HGroupIdSerializer(
        validators=[HGroupValidator()],
        required=False,
    )

    def validate(self, data):
        result = {}
        if data.get("start_date") and data.get("finish_date"):

            result["create_date__range"] = [
                data.get("start_date"),
                data.get("finish_date"),
            ]

        if data.get("group_id"):
            result["hgroup"] = data.get("group_id")

        return result


class KindIdSerializer(serializers.Field):
    def to_internal_value(self, data):
        return Kind.objects.get(id=data)

    def to_representation(self, instance):
        return instance.id


class PostReportQueryParamsSerializer(serializers.Serializer):

    kind = KindIdSerializer(validators=[KindIdValidator()])
    start_date = serializers.DateTimeField(required=False)
    finish_date = serializers.DateTimeField(required=False)
    post_ids = serializers.ListField(
        child=serializers.IntegerField(),
        required=False,
    )
    group_id = HGroupIdSerializer(required=False)
    name = serializers.CharField(required=False)
    comment = serializers.CharField(required=False)


class KindQueryParamsSerializer(serializers.Serializer):
    kind = serializers.CharField(required=True)


class ReportPatchSerializer(serializers.ModelSerializer):
    class Meta:
        model = Report
        fields = ('name', )
