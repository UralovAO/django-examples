from rest_framework.exceptions import ValidationError


class HGroupValidator:

    def __call__(self, value):
        if value is None:
            raise ValidationError(
                "Group with passed harvester id does not exist",
            )


class KindIdValidator:

    def __call__(self, value):
        if value.exec_file_name is None:
            raise ValidationError(
                'Attribute "exec_file_name" is empty',
            )
