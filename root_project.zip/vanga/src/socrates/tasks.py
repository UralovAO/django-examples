import logging
import os
import shutil
import tempfile

import papermill as pm
from celery import shared_task
from django.conf import settings
from django.core.files.base import File
from django.utils import timezone
from sentry_sdk import capture_message

from socrates.models import Report


logger = logging.getLogger(__name__)


NOTEBOOK_DIR = os.path.join(settings.BASE_DIR, 'socrates', 'executor', 'files')
ARTIFACT_PATH = os.path.join(NOTEBOOK_DIR, 'output.ipynb')


@shared_task  # type: ignore
def execute(report_id):

    report = Report.objects.get(id=report_id)
    report.mark_as_in_progress()

    params = report.params
    params["citiair_token"] = os.environ.get('CITYAIR_TOKEN')

    temp_dir = tempfile.mkdtemp()
    temp_report_file_path = os.path.join(temp_dir, 'report.xlsx')
    temp_artifact_path = os.path.join(temp_dir, 'artifact_output.ipynb')
    shutil.copyfile(ARTIFACT_PATH, temp_artifact_path)

    # passing path to notebook
    params['temp_report_file_path'] = temp_report_file_path

    notebook_path = os.path.join(NOTEBOOK_DIR, report.kind.exec_file_name)
    assert os.path.exists(notebook_path)

    try:
        pm.execute_notebook(
            input_path=notebook_path,
            output_path=temp_artifact_path,
            parameters=params,
        )
    except Exception as e:
        logger.exception('notebook report error')
        report.mark_as_error()
        capture_message(e)
        return

    report_file = open(temp_report_file_path, 'rb')
    report.file.save(
        f'{timezone.now().strftime("%Y%m%d")}/{report_id}.xlsx',
        File(report_file),
    )
    report.mark_as_ready()

    report_file.close()
    shutil.rmtree(temp_dir)
