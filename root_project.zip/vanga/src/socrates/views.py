from django.conf import settings
from django.http import HttpResponseBadRequest
# from django.http.response import HttpResponseRedirect
from django.shortcuts import get_object_or_404
from rest_framework.decorators import api_view
from rest_framework.request import Request
from rest_framework.response import Response

from forecast.s3 import create_presigned_url, get_client
from socrates.models import Kind, Report
from socrates.serializers import GetReportQueryParamsSerializer, \
    KindSerializer, PostReportQueryParamsSerializer, ReportPatchSerializer, \
    ReportSerializer
from socrates.tasks import execute


s3_client = get_client()


@api_view(["GET"])
def presigned_url(request: Request, pk):

    try:
        report = Report.objects.get(id=pk)
    except Report.DoesNotExist:
        return HttpResponseBadRequest()

    if report.is_ready:
        presigned_url = create_presigned_url(
            s3_client,
            settings.YANDEX_REPORTS_BUCKET_NAME,
            report.file.file.name,
            300,
            report.name+'.xlsx',  # TODO get format from kind
        )

        return Response({"presigned_url": presigned_url})
    else:
        return HttpResponseBadRequest()


@api_view(["GET", "POST", "DELETE", "PATCH"])
def reports(request: Request, pk=None):
    """
    """
    if request.method == 'GET':
        params_serializer = GetReportQueryParamsSerializer(
            data=request.query_params,
        )
        params_serializer.is_valid(raise_exception=True)
        validated_params = params_serializer.validated_data

        if pk:
            report = get_object_or_404(
                Report.objects.filter(
                    hgroup_id__in=request.user.hgroups.all(),
                    **validated_params,
                ),
                pk=pk,
            )
            return Response(ReportSerializer(report).data)

        qs = Report.objects.filter(
            hgroup_id__in=request.user.hgroups.all(),
            **validated_params,
        )
        result = ReportSerializer(qs, many=True)
        return Response(result.data)

    elif request.method == "POST":
        params_serializer = PostReportQueryParamsSerializer(data=request.data)
        params_serializer.is_valid(raise_exception=True)
        validated_params = params_serializer.validated_data
        report = Report.objects.create(
            kind=validated_params["kind"],
            user=request.user,
            params=params_serializer.data,
            comment=validated_params.get("comment"),
            name=validated_params.get("name"),
            hgroup=validated_params.get("group_id"),
        )

        execute.delay(report.id)
        report.refresh_from_db()
        return Response(ReportSerializer(report).data)

    elif request.method == "DELETE":
        try:
            report = Report.objects.get(id=pk)
            if report.file.name:
                s3_client.delete_object(
                    Bucket=settings.YANDEX_REPORTS_BUCKET_NAME,
                    Key=report.file.file.name,
                )
            report.delete()
            return Response(status=204)
        except Report.DoesNotExist:
            return HttpResponseBadRequest()
    elif request.method == 'PATCH':
        report = get_object_or_404(
            Report.objects.filter(hgroup_id__in=request.user.hgroups.all()),
            pk=pk,
        )

        serializer = ReportPatchSerializer(
            report, data=request.data, partial=True,
        )
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)


@api_view(["GET"])
def kinds(request: Request, pk=None):

    if pk:
        kinds = Kind.objects.filter(id=pk)
    else:
        kinds = Kind.objects.all()

    result = KindSerializer(kinds, many=True)

    return Response(result.data)
