from django.db import models

from core.models import Group, User
from socrates.yandex_s3_storage import ReportsStorage


class Kind(models.Model):
    name = models.CharField(max_length=50)
    short_description = models.CharField(max_length=100, null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    params = models.JSONField(default=dict)
    exec_file_name = models.CharField(max_length=30, default='')
    hgroup = models.ForeignKey(Group, on_delete=models.CASCADE)

    def __str__(self):
        return f'{self.name}#{self.id}'


class Report(models.Model):
    class Status(models.TextChoices):
        QUEUED = 'QUEUED'
        IN_PROGRESS = 'IN_PROGRESS'
        READY = 'READY'
        ERROR = 'ERROR'

    kind = models.ForeignKey(Kind, on_delete=models.PROTECT)
    user = models.ForeignKey(User, on_delete=models.PROTECT)
    status = models.CharField(
        max_length=11, choices=Status.choices, default=Status.QUEUED,
    )
    create_date = models.DateTimeField(auto_now_add=True)
    update_date = models.DateTimeField(auto_now=True)
    file = models.FileField(storage=ReportsStorage(), null=True, blank=True)
    params = models.JSONField(default=dict)
    hgroup = models.ForeignKey(Group, on_delete=models.CASCADE)
    name = models.CharField(max_length=100, default='')
    comment = models.TextField(null=True, blank=True)

    def mark_as_ready(self):
        self.status = self.Status.READY
        self.save(update_fields=('status', ))

    def mark_as_in_progress(self):
        self.status = self.Status.IN_PROGRESS
        self.save(update_fields=('status', ))

    def mark_as_error(self):
        self.status = self.Status.ERROR
        self.save(update_fields=('status', ))

    @property
    def is_ready(self):
        return self.status == self.Status.READY
