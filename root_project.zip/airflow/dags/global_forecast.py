import os

from airflow import DAG
from datetime import datetime, timedelta
from airflow.models import Variable

from dagutils import (
    create_operator,
    slack_modeling_alert,
)


DAG_ID = os.path.splitext(os.path.basename(__file__))[0]


default_args = {
    'owner': 'airflow',
    'description': 'Global forecast',
    'depend_on_past': False,
    'start_date': datetime(2022, 3, 1),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=15),
    'on_failure_callback': slack_modeling_alert,
}


# grafana will cut this postfix
cont_name_postfix = f"{'_'*22}{{{{ ti.start_date.strftime('%Y%m%dT%H%M%S')  }}}}"


# @todo: Error callback that will destroy vm
with DAG(DAG_ID, default_args=default_args, schedule_interval="30 1 * * *", catchup=False) as dag:
    # create flows

    vm_queue_name = 'global-forecast'
    vm_name = f'm-worker-{vm_queue_name}'

    # vm_name = f'm-worker-global-forecast'
    create_command = [
        '/bin/yc',
        'compute',
        'instance',
        'create',
        '--name',
        vm_name,
        '--cores',
        '2',
        '--memory',
        '6',
        '--hostname',
        vm_name,
        '--service-account-id',
        'aje78ar1a7gnfk4lpmpf',
        '--metadata-from-file',
        'user-data=/opt/airflow/worker-cloud-init.yml',
        '--create-boot-disk',
        'size=40,image-id=fd88u6noc891qufef1q4',
        '--zone',
        'ru-central1-a',
        '--preemptible',
        '--network-interface',
        'subnet-name=modeling-subnet-a',
        '&&',
        'sleep',
        '300',  # give 5 minutes for the cloud-init (better to listen port and host from worker http logs port)
    ]
    delete_command = [
        '/bin/yc',
        'compute',
        'instance',
        'delete',
        vm_name,
    ]
    create_vm_task_name = f'create_vm_{vm_name}'
    cont_name = f'airflow_{create_vm_task_name}{cont_name_postfix}'
    create_vm_operator = create_operator(
        f"""/bin/bash -ci \"{' '.join(create_command)}\" """,
        task_id=create_vm_task_name,
        mem_limit="1g",
        cpus=1.0,
        image="cr.yandex/crpf7rplkice94jchr2l/yc-tools:latest",
        auto_remove=True,  # temporary disabled docker containers auto-removal for the debug purposes.
        queue='forecast',  # must be ran on build machine (or with certain permissions)
        container_name=cont_name,
    )
    assert vm_name.startswith('m-worker'), \
        'You are going to delete some production instance '
    delete_vm_task_name = f'delete_vm_{vm_name}'
    cont_name = f'airflow_{delete_vm_task_name}{cont_name_postfix}'
    delete_vm_operator = create_operator(
        f"""/bin/bash -ci \"{' '.join(delete_command)}\" """,
        task_id=delete_vm_task_name,
        mem_limit="1g",
        cpus=1.0,
        queue='forecast',
        image="cr.yandex/crpf7rplkice94jchr2l/yc-tools:latest",
        auto_remove=True,  # must be ran on build machine (or with certain permissions)
        trigger_rule='all_done',  # will be executed when all parents are done (failed, queued, succcess)
        container_name=cont_name,
    )

    task_name = 'download_and_upload'
    cont_name = f'airflow_{task_name}{cont_name_postfix}'
    download_and_upload = create_operator(
        f"""/usr/bin/python3 /home/wrfuser/chimere-scripts/src/run.py ecmwf download-and-upload""",
        task_id=task_name,
        container_name=cont_name,
        queue=vm_queue_name,
        auto_remove=True,
        environment={
            'YANDEX_S3_ACCESS_KEY': Variable.get('YANDEX_S3_ACCESS_KEY'),
            'YANDEX_S3_SECRET_KEY': Variable.get('YANDEX_S3_SECRET_KEY'),
        },
    )

    create_vm_operator >> download_and_upload >> delete_vm_operator
