import logging
from datetime import datetime

from django.conf import settings

from libs.clickhouse import sql

from ..views.helpers import DateRange
from .db import clickhouse_engine


logger = logging.getLogger(__name__)

CHECK_MEASUREMENTS = settings.CHECK_MEASUREMENTS  # type: ignore
SECONDS_BACK = 6*60*60  # 6*60*60 is equal to 6 hours
SEASON_CONFIG = {
    'year': None,
    'winter': [12, 1, 2],
    'spring': [3, 4, 5],
    'summer': [6, 7, 8],
    'autumn': [9, 10, 11],
}


def execute_report_query(q_params):
    logger.debug(f"start {datetime.now()}")

    start = q_params.get("start")
    finish = q_params.get("finish")

    if start and finish:
        table_name = get_table_name(
            DateRange(
                datetime.fromisoformat(start[0][:-1]),
                datetime.fromisoformat(finish[0][:-1]),
            ).period,
        )
    else:
        table_name = sql.API_RAW_60_TABLE_NAME

    if q_params['dimensions'] is not None:
        query = f"SELECT {q_params['dimensions']}, {q_params['metrics']} " \
                f"FROM {table_name} " \
                f"WHERE {q_params['field_name']}={q_params['instance_id']} " \
                f"GROUP BY {q_params['dimensions']} " \
                f"ORDER BY {q_params['dimensions']}"

    elif "round(argMin(AQI, date))" in q_params['metrics']:  # noqa TODO change this work around

        if q_params['field_name'] == 'city_id':
            # city AQI is max AQI of his stations
            inner_inner_query = f"(SELECT max(AQI) as AQI, date, city_id " \
                                f"FROM {table_name} " \
                                f"WHERE {q_params['field_name']}=" \
                                f"{q_params['instance_id']} " \
                                f"GROUP BY city_id, date)"
        elif q_params['field_name'] == 'source_id':
            inner_inner_query = table_name
        else:
            assert 0, q_params['field_name']

        inner_query = f"SELECT top 2 AQI, date " \
                      f"FROM {inner_inner_query} " \
                      f"WHERE {q_params['field_name']}=" \
                      f"{q_params['instance_id']} " \
                      f"ORDER BY date desc"

        query = f"SELECT {q_params['metrics']} " \
                f"FROM ({inner_query})"

    else:
        query = f"SELECT {q_params['metrics']} " \
                f"FROM {table_name} " \
                f"WHERE {q_params['field_name']}={q_params['instance_id']} "

    data = clickhouse_engine.execute(query)

    logger.debug(f"query = {query}")
    logger.debug(f"finish {datetime.now()}")
    return list(data)


def get_ids_with_measurements(field_name, ids, seconds_ago):

    # function returns True when exists data for object at least for
    # 24 hours by default

    if not settings.CHECK_MEASUREMENTS:
        return ids

    data = clickhouse_engine.execute(
        f"SELECT {field_name} "
        f"FROM {sql.API_RAW_TABLE_NAME} "
        f"WHERE {field_name} in {ids} AND date > now()-{seconds_ago}",
    )
    data = [x[0] for x in data]
    return data


def get_table_name(period):
    if period == 20:
        res = sql.API_RAW_TABLE_NAME
    elif period == 60:
        res = sql.API_RAW_60_TABLE_NAME
    elif period == 1440:
        res = sql.API_RAW_1440_TABLE_NAME
    return res


def get_aqi(field_name, instance_id, dates, period):

    table_name = get_table_name(period)
    dates = [f"parseDateTimeBestEffortOrNull(\'{d}\')" for d in dates]
    dates_str = ",".join(dates)

    if field_name == 'source_id':
        query = f"SELECT argMax(AQI, timestamp), date " \
                f"FROM {table_name} " \
                f"WHERE date in ({dates_str}) AND " \
                f"{field_name} = {instance_id} " \
                f"GROUP BY date " \
                f"ORDER BY date"
    elif field_name == 'city_id':

        inner_q = f"SELECT argMax(AQI, timestamp) as AQI, date, source_id " \
                  f"FROM {table_name} " \
                  f"WHERE date in ({dates_str}) AND " \
                  f"{field_name} = {instance_id} " \
                  f"GROUP BY date, source_id"

        query = f"SELECT max(AQI), date FROM ({inner_q}) GROUP BY date " \
                f"ORDER BY date"

    data = list(clickhouse_engine.execute(query))
    return data


def get_features_by_measurement_name(measurement_name, feature_column_name):
    return clickhouse_engine.execute(
                f"SELECT DISTINCT {feature_column_name} "
                f"FROM {sql.API_RAW_TABLE_NAME} "
                f"WHERE {measurement_name} is not null ",
            )
