import logging

from sentry_sdk import capture_message

from core.logging import HttpRequestLogger


TO_LOG_PATH = "/api"


def logging_middleware(get_response):
    def middleware(request):
        request_logger = HttpRequestLogger()
        try:
            request_logger.fill_from_request(request)
            response = get_response(request)
            if not request.path.startswith(TO_LOG_PATH):
                return response

        except Exception:
            logging.error(
                "failed to make http log request data: %s",
                exc_info=True,
            )
            capture_message('failed to make http log request data')
            # raise
        else:
            # user initated by view middleware, so we can not get it
            # before view processed
            request_logger.payload['user']['name'] = str(request.user)
            request_logger.fill_from_response(response)

        try:
            request_logger.send()
        except Exception:

            logging.error(
                "failed to send http log request data: %s",
                exc_info=True,
            )
        #     # todo: add settings to enable/disable filebeat
        #     # use this settings in middleware test only

        del request_logger

        return response

    return middleware
