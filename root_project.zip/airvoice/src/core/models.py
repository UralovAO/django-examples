from typing import Dict

from django.contrib.auth.models import AbstractUser
from django.contrib.gis.db.models import PointField
from django.contrib.postgres.fields import ArrayField
from django.db import models

from geo.repositories.measurements import get_aqi


class TranslatableModelMixin(models.Model):
    name_ru = models.CharField(max_length=100, null=True)
    name = models.CharField(max_length=100, null=True)

    class Meta:
        abstract = True


class HarvesterModelMixin(models.Model):
    harvester_id = models.BigIntegerField(null=True, unique=True)

    class CloudProvider(models.TextChoices):

        YANDEX = "1", "YANDEX"
        AWS = "2", "AWS"

    cloud_provider = models.CharField(
        max_length=100,
        choices=CloudProvider.choices,
        default=CloudProvider.YANDEX,
    )

    class Meta:
        abstract = True


class FeatureMixin(models.Model):
    timeseries: Dict[str, list] = {"date": [], "AQI": []}
    has_any_timeseries = False
    point = PointField(unique=False)

    measurement_names = ArrayField(
        models.CharField(max_length=20),
        null=True,
    )

    def remove_unmeasured_timeseries(self):
        if self.measurement_names is None:
            self.timeseries = {"date": self.timeseries["date"]}
            return

        measured_names = list(
            set(self.measurement_names) & set(self.timeseries.keys()),
        )

        self.timeseries = {
            k: v for k, v in self.timeseries.items()
            if k in measured_names or k == 'date'
        }

    def add_aqi(self, period):

        if "AQI" not in self.timeseries.keys():
            return

        aqi_calculated = get_aqi(
            self.__class__.__name__.lower()+"_id",
            self.id,
            self.timeseries["date"],
            period,
        )

        # merging timeseries and aqi calculated
        aqis = []
        for ts_date in self.timeseries["date"]:

            aqi = [aqi for aqi, date in aqi_calculated if date == ts_date]
            aqis.append(aqi[0] if len(aqi) > 0 else None)

        self.timeseries["AQI"] = aqis

    class Meta:
        abstract = True


class User(AbstractUser):
    pass
