import json
import logging
import socket
from datetime import datetime

from django.conf import settings
from django.core.handlers.wsgi import WSGIRequest
from furl import furl  # type: ignore


HEADERS_TO_SKIP = ("cookie", "authorization")
VECTOR_SOCKET_TIMEOUT_IN_SECONDS = 1.01
TEXT_DATA_LIMIT = 5 * 10 ** 4


def bytes_to_msg(byte_string):
    return byte_string.decode()[:TEXT_DATA_LIMIT]


def header_to_msg(header_name):
    return header_name.replace('-', '_').lower()


class HttpRequestLogger:
    def __init__(self, endpoint=''):
        self.endpoint = endpoint
        self.payload = {
            'outbound': False,
            'application': settings.APPLICATION_NAME,
            'http': {
                'request': {
                    'query_params': {},
                    'method': {},
                    'header': {},
                    'body': {},
                },
                'response': {
                    'body': {},
                },
            },
            'url': {},
            'user': {},
            'request_date': {},
        }

    def fill_from_request(self, request: WSGIRequest):
        req = self.payload['http']['request']

        self.payload['url']['path'] = request.path
        self.payload['request_date'] = datetime.now().strftime(
            "%Y-%m-%d %H:%M:%S",
        )

        req['query_params'] = str(furl().add(args=request.GET.dict()).query)
        req['method'] = request.method.upper()  # type: ignore
        req["body"]['content'] = bytes_to_msg(request.body)

        for header_name, header_value in request.headers.items():
            if header_name.lower() in HEADERS_TO_SKIP:
                continue
            try:
                req['header'][header_to_msg(header_name)] = header_value
            except IndexError:
                pass

    def fill_from_response(self, response):
        resp = self.payload['http']['response']
        resp['status_code'] = response.status_code
        resp['body']['content'] = bytes_to_msg(response.content)
        resp['body']['bytes'] = len(response.content)

    def send(self):
        # sock = socket.socket()
        sock = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)
        sock.settimeout(VECTOR_SOCKET_TIMEOUT_IN_SECONDS)
        url, port = settings.VECTOR_URL.split(":")
        sock.connect((url, int(port)))
        message = f"{json.dumps(self.payload)}\n".encode()
        sock.send(message)
        sock.close()
        logging.debug(
            "sent http log message to %s - %s",
            settings.VECTOR_URL,
            message,
        )


# TODO
"""
add tests
- missed url
- post json payload
- not stored auth headers
- not stored cookies
"""
