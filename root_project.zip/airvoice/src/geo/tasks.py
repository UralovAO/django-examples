import json
import logging
import sys
from enum import Enum

from celery import shared_task
from django.conf import settings
from django.contrib.gis.geos import GEOSGeometry
from django.db import IntegrityError
from sentry_sdk import capture_message
from sqlalchemy.sql import text  # type: ignore

from geo.models import City, GeoCatalog, Source
from geo.repositories.db import clickhouse_engine
from geo.repositories.measurements import get_features_by_measurement_name
from libs.clickhouse import sql
from libs.clickhouse.utils import get_last_timestamps_2, \
    get_last_timestamps_60_2, get_last_timestamps_1440_2, \
    prep_harvester_data
from libs.harvester.download_helpers import get_cities, get_packets, \
    get_stations


# import psutil
# from psutil._common import bytes2human


DEFAULT_START_TIMESTAMP = 0  # 1644202819001101
logger = logging.getLogger(__name__)
SAKHALIN_PATH = './geo/files/sakhalin_simplified.geojson'


class Period(Enum):
    FIVE_MINS = 1
    TWENTY_MINS = 2
    HOUR = 3
    DAY = 4
    SOURCE = 100


LIMIT = 10**4


COLUMNS_RAW = (
    "country_id",
    "region_id",
    "city_id",
    "source_id",

    "date",

    "AQI",

    "PM2.5",
    "PM10",
    "TSP",

    "T",
    "RH",
    "P",

    "CO",
    "NO2",
    "O3",
    "H2S",
    "SO2",
    "timestamp",
    "date_create",
    "instant_AQI",
    )


@shared_task(queue='low_priority_queue')  # type: ignore
# @shared_task  # type: ignore
def sync_cities():
    # logging.info(
    #     f'Memory stats before get_cities(): {psutil.virtual_memory()}',
    # )
    cities_harvester = get_cities()
    # logging.info(
    #     f'Memory stats after get_cities(): {psutil.virtual_memory()}',
    # )

    for city_harvester in cities_harvester:
        logging.info(f'start sync city with harvester_id = '
                     f'{city_harvester["harvester_id"]}')
        try:
            city, is_new = City.objects.update_or_create(
                harvester_id=city_harvester["harvester_id"],
                cloud_provider=city_harvester["cloud_provider"],
                defaults={**city_harvester},
            )
            if is_new:
                logger.info("created city %s", city)
        except IntegrityError:
            logging.info(
                f'IntegrityError while creating mo with harvester_id = '
                f'{city_harvester["harvester_id"]}. No need to worry '
                f'because this mo is created in another celery worker.',
            )
            continue

    qs = GeoCatalog.objects.all()

    for city in City.objects.filter(country__isnull=True):
        city.country = qs.filter(geometry__covers=city.point).first()
        city.save(update_fields=["country"])

        if city.country is None:
            capture_message(
                f'Application can not define country for city {city.name}',
            )

    # logging.info(
    #     f'Memory stats end sync_cities(): {psutil.virtual_memory()}'
    # )


@shared_task  # type: ignore
def sync_stations():
    # return
    # logging.info(
    #     f'Memory stats before get_stations(): {psutil.virtual_memory()}'
    # )
    mo_data = get_stations()
    # logging.info(
    #     f'Memory stats after get_stations(): {psutil.virtual_memory()}'
    # )

    # last_timestamps_1 = get_last_timestamps_1()
    # last_timestamps_60_1 = get_last_timestamps_60_1()
    # last_timestamps_1440_1 = get_last_timestamps_1440_1()

    last_timestamps_2 = get_last_timestamps_2()
    last_timestamps_60_2 = get_last_timestamps_60_2()
    last_timestamps_1440_2 = get_last_timestamps_1440_2()

    for mo in mo_data:
        logging.info(f'start sync mo with harvester_id = {mo["harvester_id"]}')
        try:
            source, _ = Source.objects.update_or_create(
                harvester_id=mo["harvester_id"],
                cloud_provider=mo["cloud_provider"],
                defaults={**mo},
            )
        except IntegrityError:
            logging.info(
                f'IntegrityError while creating mo with harvester_id = '
                f'{mo["harvester_id"]}. No need to worry because this mo is '
                f'created in another celery worker.',
            )
            continue

        # sync_measurements(
        #     source,
        #     sql.SYNC_RAW_TABLE_NAME_1,
        #     sql.SYNC_RAW_60_TABLE_NAME_1,
        #     sql.SYNC_RAW_1440_TABLE_NAME_1,
        #     last_timestamps_1,
        #     last_timestamps_60_1,
        #     last_timestamps_1440_1,
        # )
        # logging.info(
        #     f'Memory stats before '
        #     f'sync_measurements(): {psutil.virtual_memory()}',
        # )
        sync_measurements(
            source,
            sql.SYNC_RAW_TABLE_NAME_2,
            sql.SYNC_RAW_60_TABLE_NAME_2,
            sql.SYNC_RAW_1440_TABLE_NAME_2,
            last_timestamps_2,
            last_timestamps_60_2,
            last_timestamps_1440_2,
        )
        # logging.info(
        #     f'Memory stats after '
        #     f'sync_measurements(): {psutil.virtual_memory()}'
        # )
    # delete data became not public
    # sync_not_public_station(
    #     mo_data,
    #     sql.SYNC_RAW_TABLE_NAME_1,
    #     sql.SYNC_RAW_60_TABLE_NAME_1,
    #     sql.SYNC_RAW_1440_TABLE_NAME_1,
    # )

    # delete data became not public
    sync_not_public_station(
        mo_data,
        sql.SYNC_RAW_TABLE_NAME_2,
        sql.SYNC_RAW_60_TABLE_NAME_2,
        sql.SYNC_RAW_1440_TABLE_NAME_2,
    )

    # logging.info(
    #     f'Memory stats end sync_stations(): {psutil.virtual_memory()}',
    # )


def insert_packets(df, source_id, columns, table_name):
    if df is not None:

        city_id = Source.objects.get(id=source_id).city_id
        tuples = prep_harvester_data(df, source_id, city_id, columns)

        if len(tuples) > 1:  # this doesnt work when len(tuples) == 1
            clickhouse_engine.execute(sql.INSERT(table_name), tuples)
        elif len(tuples) == 1:  # but this works
            clickhouse_engine.execute(
                text(f"INSERT INTO {table_name} VALUES :x"),
                x=tuples[0],
            )

        logger.info(
            f"inserted to clickhouse table {table_name} {len(tuples)} packets"
            f" of {source_id} station",
        )


def make_null_prohibited_measurements(df):

    if df is None:
        return df

    prohibited_measurements = list(
        set(settings.STORED_MEASUREMENTS_NAMES) - set(settings.AQI_NAMES),
    )

    for m in prohibited_measurements:
        df[m] = None
    return df


def get_sakhalin_geometries():
    with open(SAKHALIN_PATH, 'r') as fd:
        data = json.load(fd)
    return GEOSGeometry(str(data['features'][0]['geometry']))


SAKHALIN = get_sakhalin_geometries()


def sakhalin_covers_source(source_id):
    return SAKHALIN.covers(Source.objects.get(id=source_id).point)


# def get_readable_memory_message(message):
#     result = ''
#     for name in message._fields:
#         value = getattr(message, name)
#         if name != 'percent':
#             value = bytes2human(value)
#
#         result = result + '\n' + '%-10s : %7s' % (name.capitalize(), value)
#     return result


@shared_task  # type: ignore
def sync_one_table(source_id, source_harvester_id, last_timestamp,
                   period, table_name):

    logging.info(
        f'sync source_id = {source_id}, '
        f'source_harvester_id = {source_harvester_id}, table = {table_name}, '
        f'last_timestamp = {last_timestamp}, period = {period}',
    )
    # logging.info(
    #     f'Memory stats start sync_one_table()'
    #     f': {get_readable_memory_message(psutil.virtual_memory())}',
    # )

    # if source_id == 94:
    #     return
    filter = {
        'Take': LIMIT,
        'MoId': source_harvester_id,
        'IntervalType': period,
        'FilterType': 2,
        'FromTimestamp': last_timestamp,
        "WithAqi": True,
    }

    df = get_packets(filter, Source.objects.get(pk=source_id).cloud_provider)
    logging.info(f'size of df = {sys.getsizeof(df)} bytes')

    # logging.info(
    #     f'Memory stats after get_packets(filter)'
    #     f': {get_readable_memory_message(psutil.virtual_memory())}',
    # )
    # For Sakhalin we must display on map only AQI
    # other measurements came from harvester we delete
    if sakhalin_covers_source(source_id):
        df = make_null_prohibited_measurements(df)

    insert_packets(df, source_id, COLUMNS_RAW, table_name)
    # logging.info(
    #     f'Memory stats end sync_one_table()'
    #     f': {get_readable_memory_message(psutil.virtual_memory())}',
    # )


def sync_measurements(source, raw_table_name, raw_60_table_name,
                      raw_1440_table_name, last_timestamps, last_timestamps_60,
                      last_timestamps_1440):

    last_timestamp = last_timestamps.get(
        source.id,
        DEFAULT_START_TIMESTAMP,
    )

    last_timestamp_60 = last_timestamps_60.get(
        source.id,
        DEFAULT_START_TIMESTAMP,
    )

    last_timestamp_1440 = last_timestamps_1440.get(
        source.id,
        DEFAULT_START_TIMESTAMP,
    )

    sync_one_table.delay(source.id, source.harvester_id, last_timestamp,
                         Period.TWENTY_MINS.value, raw_table_name)

    logger.info(
        "enqueued sync %s of %s station from timestamp %s",
        raw_table_name,
        source.id,
        last_timestamp,
    )

    sync_one_table.delay(source.id, source.harvester_id, last_timestamp_60,
                         Period.HOUR.value, raw_60_table_name)

    logger.info(
        "enqueued sync %s of %s station from timestamp %s",
        raw_60_table_name,
        source.id,
        last_timestamp_60,
    )

    sync_one_table.delay(source.id, source.harvester_id, last_timestamp_1440,
                         Period.DAY.value, raw_1440_table_name)

    logger.info(
            "enqueued sync %s of %s station from timestamp %s",
            raw_1440_table_name,
            source.id,
            last_timestamp_1440,
        )


@shared_task  # type: ignore
def delete_measurements(ids_list, raw_table_name, raw_60_table_name,
                        raw_1440_table_name):
    if ids_list is not None and len(ids_list) > 0:
        ids_str = ",".join([str(x) for x in ids_list])

        clickhouse_engine.execute(
            sql.DELETE(raw_table_name, f'source_id in ({ids_str})'),
        )
        clickhouse_engine.execute(
            sql.DELETE(raw_60_table_name, f'source_id in ({ids_str})'),
        )
        clickhouse_engine.execute(
            sql.DELETE(raw_1440_table_name, f'source_id in ({ids_str})'),
        )
        logger.info(
            f"deleted in clickhouse not public data, "
            f"condition is: source_id in {ids_str}",
        )


@shared_task  # type: ignore
def sync_not_public_station(mo_data, raw_table_name, raw_60_table_name,
                            raw_1440_table_name):
    sources_to_delete = Source.objects.exclude(
        harvester_id__in=[x["harvester_id"] for x in mo_data],
    )
    source_id_list = [x.pk for x in sources_to_delete]

    delete_measurements.delay(
        source_id_list,
        raw_table_name,
        raw_60_table_name,
        raw_1440_table_name,
    )
    sources_to_delete.delete()


def get_features_with_measurement_names(feature_column_name):
    m_s = {}  # key - measurement_name, value - list of id of features
    all_features = []
    for m_name in settings.STORED_MEASUREMENTS_NAMES:
        m_name_quoted = '`' + m_name + '`'  # for query with clause on `PM2.5`

        features = get_features_by_measurement_name(
            m_name_quoted, feature_column_name,
        )

        features = [s[0] for s in list(features)]
        all_features = all_features + features
        m_s[m_name] = features

    all_features = set(all_features)

    res = {}  # key - id of feature, value - list of measurement_names
    for feature in all_features:
        measurement_names = []
        for measurement_name in m_s.keys():
            if feature in m_s[measurement_name]:
                measurement_names.append(measurement_name)
        res[feature] = measurement_names

    return res


@shared_task(queue='low_priority_queue')  # type: ignore
# @shared_task  # type: ignore
def update_measurement_names():
    # logging.info(
    #     f'Memory stats start '
    #     f'update_measurement_names(): {psutil.virtual_memory()}',
    # )
    sources_data = get_features_with_measurement_names("source_id")
    for source_id in sources_data.keys():
        Source.objects.filter(id=source_id).update(
            measurement_names=sources_data[source_id],
        )

    cities_data = get_features_with_measurement_names("city_id")
    for city_id in cities_data.keys():
        City.objects.filter(id=city_id).update(
            measurement_names=cities_data[city_id],
        )
    # logging.info(
    #     f'Memory stats end '
    #     f'update_measurement_names(): {psutil.virtual_memory()}',
    # )
