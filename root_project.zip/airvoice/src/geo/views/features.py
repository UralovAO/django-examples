import logging

# import newrelic.agent  # type: ignore
from django.conf import settings
from django.contrib.gis.geos import Polygon
from django.core.cache import cache
from drf_yasg.utils import swagger_auto_schema  # type: ignore
from pytz import utc
from rest_framework import serializers
from rest_framework.decorators import api_view
from rest_framework.request import Request
from rest_framework.response import Response

from geo.models import City, Source
from geo.repositories.measurements import get_ids_with_measurements
from geo.serializers import CitySerializer, PointSerializer
from geo.views.cache import cells, get_cache
from geo.views.helpers import BboxValidator, DateRange, DateRangeValidator, \
    LatitudeValidator, LongitudeValidator, MeasurementsValidator, parse_uuid
from libs.clickhouse.timeseries_geo_objects import add_timeseries


logger = logging.getLogger(__name__)


API_MEASUREMENTS_NAMES = settings.API_MEASUREMENTS_NAMES


class IdsSerialazer(serializers.Field):
    def to_internal_value(self, data):
        return data.split(",")


class MeasurementsSerialazer(serializers.Field):
    def to_internal_value(self, data):
        data = data.upper().replace('AQI', settings.AQI_NAME)
        return settings.API_MEASUREMENTS_NAMES \
            if data == "ALL" else data.split(",")


class FeatureParamsSerializer(serializers.Serializer):
    west = serializers.FloatField(
        validators=[LongitudeValidator()],
        required=False,
    )
    south = serializers.FloatField(
        validators=[LatitudeValidator()],
        required=False,
    )
    east = serializers.FloatField(
        validators=[LongitudeValidator()],
        required=False,
    )
    north = serializers.FloatField(
        validators=[LatitudeValidator()],
        required=False,
    )

    geo_type = serializers.CharField(required=False)

    start = serializers.DateTimeField(required=False, default_timezone=utc)
    finish = serializers.DateTimeField(required=False, default_timezone=utc)

    ids = IdsSerialazer(required=False)

    measurements = MeasurementsSerialazer(
        required=False,
        validators=[MeasurementsValidator()],
    )

    class Meta:
        validators = [DateRangeValidator(), BboxValidator()]

    def validate(self, data):
        result = {}

        result["ids"] = data.get("ids")

        if result["ids"]:
            result["coords"] = None
            result["reverse"] = None
            result["show_sources"] = None
        else:
            coords = {
                "north": data.get("north", 90),
                "south": data.get("south", -90),
                "east": data.get("east", 180),
                "west": data.get("west", -180),
            }

            norm_coords, reverse = normalize_coords(coords)
            cell_coords = cells.get_coords(**norm_coords)
            norm_cell_coords, reverse = normalize_coords(cell_coords)

            result["coords"] = norm_cell_coords
            result["reverse"] = reverse
            result["show_sources"] = get_show_sources(coords)

        result["geo_type"] = data.get("geo_type")
        result["drange"] = DateRange(data["start"], data["finish"])
        result["measurements"] = data.get("measurements", ["AQI"])

        return result


def query_sources(bbox):
    return Source.objects.filter(point__coveredby=bbox)


def query_cities(bbox, reverse=False):
    qs = City.objects.all()
    if reverse:
        qs = qs.exclude(point__coveredby=bbox)
    else:
        qs = qs.filter(point__coveredby=bbox)
    return qs


LAT_DELTA = 2.8


def normalize_coords(coords):
    def normalize_long(val):
        if val == 180:  # it makes -180 from 180
            return 180
        return (val + 180) % 360 - 180

    reverse = False

    west = coords.get("west")
    east = coords.get("east")
    north = coords.get("north")
    south = coords.get("south")

    # after changing coords to cell's bounds with reverse=True
    # both east and west could point to 0
    # so condition (west % 360 == 0 and east % 360 == 0) is added
    if abs(west - east) >= 360 or (west % 360 == 0 and east % 360 == 0):
        norm_east = 180
        norm_west = -180
    else:
        norm_west = normalize_long(west)
        norm_east = normalize_long(east)

        reverse = norm_west > norm_east

    norm_north = north if north <= 90 else 90
    norm_south = south if south >= -90 else -90

    norm_coords = {}
    norm_coords["west"] = norm_west
    norm_coords["east"] = norm_east
    norm_coords["north"] = norm_north
    norm_coords["south"] = norm_south

    return norm_coords, reverse


def features_by_coords(coords, reverse, show_sources, **kwargs):

    west = coords.get("west", -180)
    east = coords.get("east", 180)
    south = coords.get("south", -90)
    north = coords.get("north", 90)

    bbox = Polygon.from_bbox((west, south, east, north))

    if show_sources:
        cities = query_cities(bbox)
        sources = query_sources(bbox)
    else:
        cities = query_cities(bbox, reverse=reverse)
        sources = []

    return cities, sources


def get_features_with_measurements(features):

    if len(features) == 0 or features is None:
        return features

    ids = [x.id for x in features]
    field_name, _ = parse_uuid(features[0].uuid)

    ids_with_measurements = get_ids_with_measurements(
        field_name, ids, seconds_ago=24 * 60 * 60,
    )

    return [x for x in features if x.id in ids_with_measurements]


def get_show_sources(coords):
    if coords["north"] - coords["south"] < LAT_DELTA:
        return True
    else:
        return False


@swagger_auto_schema(
    method='get',
    query_serializer=FeatureParamsSerializer(),
)
@api_view(["GET"])
def features(request: Request):
    """
    Temporary function to use it for fast prototyping.
    """

    params_serializer = FeatureParamsSerializer(
        data=request.query_params,
    )
    params_serializer.is_valid(raise_exception=True)
    validated_params = params_serializer.validated_data

    cached, key = get_cache(**validated_params)

    if cached:
        logger.debug(
            f"Cache is found for request with "
            f"query params {str(dict(request.query_params))}",
        )
        # newrelic.agent.set_transaction_name(
        #     cached["newrelic_transaction_name"],
        # )
        return Response(cached["result"])

    logger.debug(
        f"No cache for request with "
        f"query params {str(dict(request.query_params))}",
    )

    if validated_params.get("ids") is not None:
        uuids = validated_params.get("ids")
        cities = City.objects.filter(uuid__in=uuids).all()
        sources = Source.objects.filter(uuid__in=uuids).all()

        ts_name = "geo.views.features:features_by_ids"
        # newrelic.agent.set_transaction_name(ts_name)

    else:
        if validated_params.get("geo_type") == "city":

            ts_name = "geo.views.features:features_by_geo_type_city"
            # newrelic.agent.set_transaction_name(ts_name)

        else:

            ts_name = "geo.views.features:features_by_coordinates"
            # newrelic.agent.set_transaction_name(ts_name)

        cities, sources = features_by_coords(**validated_params)

    logger.debug(f"count of cities got by bbox = {len(cities)}")
    logger.debug(f"count of sources got by bbox = {len(sources)}")

    # city and sources must have measurements for last 24 hours
    # otherwise they wont be shown on map
    cities = get_features_with_measurements(cities)
    sources = get_features_with_measurements(sources)

    logger.debug(
        f"count of cities after checking existing measurements = "
        f"{len(cities)}",
    )
    logger.debug(
        f"count of sources  after checking existing measurements ="
        f" {len(sources)}",
    )

    sources = add_timeseries(
        sources,
        validated_params["drange"],
        "source",
        validated_params["measurements"],
    )

    cities = add_timeseries(
        cities,
        validated_params["drange"],
        "city",
        validated_params["measurements"],
    )

    result = {
        'type': 'FeatureCollection',
        'dates': validated_params["drange"].date_range,
        'features': [
            *PointSerializer(sources, many=True).data["features"],
            *CitySerializer(cities, many=True).data["features"],
        ],
    }

    caching_result = {
        "result": result,
        "newrelic_transaction_name": ts_name,
    }

    if key and settings.USE_CACHE:
        cache.set(key, caching_result, 20*60)

    return Response(caching_result["result"])
