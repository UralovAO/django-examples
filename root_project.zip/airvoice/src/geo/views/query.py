from rest_framework.decorators import api_view
from rest_framework.request import Request
from rest_framework.response import Response

from geo.repositories.measurements import execute_report_query
from geo.views.helpers import parse_uuid


METRICS_CONFIG = {
    "count_aqi": "count(AQI)",
    "avg_aqi": "avg(AQI)",
    "prev_latest_aqi": "round(argMin(AQI, date))",
    "latest_aqi": "round(argMax(AQI, date))",
    "latest_t": "round(argMax(T, date))",
    "latest_p": "round(argMax(P, date))",
    "latest_rh": "round(argMax(RH, date))",
    "start_measurements_date": "min(date)",
}


DIM_CONFIG = {
    "day_of_week": "toDayOfWeek(date)",
    "hour": "toHour(date)",
    "aqi": "AQI",
    "season": "CASE WHEN toMonth(date) in (12,1,2) THEN 'winter' "
              "WHEN  toMonth(date) in (3,4,5) THEN 'spring' "
              "WHEN  toMonth(date) in (6,7,8) THEN 'summer' "
              "WHEN  toMonth(date) in (9,10,11) THEN 'autumn' END",
}


Q_ALL_DATA = [
    {
        'metrics': 'prev_latest_aqi,latest_aqi',
        'name': 'latest_aqi',
    },
    {
        'metrics': 'latest_t,latest_p,latest_rh',
        'name': 'latest_measurements',
    },
    {
        'dimensions': 'aqi',
        'metrics': 'count_aqi',
        'name': 'distributon_aqi',
    },
    {
        'dimensions': 'hour',
        'metrics': 'avg_aqi',
        'name': 'avg_aqi_by_hour',
    },
    {
        'dimensions': 'day_of_week',
        'metrics': 'avg_aqi',
        'name': 'avg_aqi_by_day_of_week',
    },
    {
        'dimensions': 'aqi,season',
        'metrics': 'count_aqi',
        'name': 'season_distributon_aqi',
    },
    {
        'dimensions': 'hour,season',
        'metrics': 'avg_aqi',
        'name': 'season_avg_aqi_by_hour',
    },
    {
        'dimensions': 'day_of_week,season',
        'metrics': 'avg_aqi',
        'name': 'season_avg_aqi_by_day_of_week',
    },
    {
        'metrics': 'start_measurements_date',
        'name': 'start_measurements_date',
    },
]


class Query:
    def __init__(self, feature, dimensions, metrics, name, start=None,
                 finish=None):
        self.name = name
        self.feature = {"id": feature}
        self.result = []
        self.query = {
            "dimensions": dimensions.split(",") if dimensions is not None
            else None,
            "metrics": metrics.split(","),
            "name": name,
            "start": start,
            "finish": finish,
        }

    def execute(self):

        field_name, instance_id = parse_uuid(self.feature["id"])

        if self.query["dimensions"] is not None:
            dimensions = ",".join(
                [DIM_CONFIG[dim] for dim in self.query["dimensions"]],
            )
        else:
            dimensions = None

        metrics = ",".join([METRICS_CONFIG[m] for m in self.query["metrics"]])

        query_params = {
            "field_name": field_name,
            "instance_id": instance_id,
            "dimensions": dimensions,
            "metrics": metrics,
            "start": self.query["start"],
            "finish": self.query["finish"],
        }

        if self.query["dimensions"] is not None:
            num_dim = len(self.query["dimensions"])
            for row in execute_report_query(query_params):
                self.result.append(
                    {
                        "dimensions": [row[idx] for idx in range(num_dim)],
                        "metrics": [row[idx] for idx in
                                    range(num_dim, len(row))
                                    ],
                     },
                )
        else:
            for row in execute_report_query(query_params):
                self.result.append(
                    {
                        "dimensions": [],
                        "metrics": list(row),
                     },
                )


def execute_q(query_params):

    res_list = []
    for q in query_params["q"]:
        query = Query(
            query_params["feature"][0],
            q.get("dimensions"),
            q.get("metrics"),
            q.get("name"),
            query_params.get("start"),
            query_params.get("finish"),
        )
        query.execute()

        res = {"name": query.name,
               "feature": query.feature,
               "result": query.result,
               "query": query.query,
               }

        res_list.append(res)

    return res_list


@api_view(["GET"])
def execute_query(request: Request):

    query_params = dict(request.query_params)

    if query_params.get("named_q") == ["all_data"]:
        query_params = {
            'feature': [query_params["feature"][0]],
            'q': Q_ALL_DATA,
        }

    else:
        q_value_list = []
        for q_value in query_params["q"]:
            q_value_list.append(
                {
                    param.split(":")[0]: param.split(":")[1]
                    for param in q_value.split(";")
                },
            )

        query_params["q"] = q_value_list

    data = execute_q(query_params)
    # cache.set(key, data, 60*60*24)
    return Response(data)
