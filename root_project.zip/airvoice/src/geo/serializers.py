from django.conf import settings
from rest_framework import serializers

from core.serializers import ApiFeatureSerializer
from geo.models import City, Source


class TimeseriesSerialazer(serializers.Field):
    def to_representation(self, value):
        AQI_NAME = settings.AQI_NAME

        aqis = value.get(AQI_NAME)
        if aqis:
            del value[AQI_NAME]
            value["AQI"] = aqis

        return value


class CitySerializer(ApiFeatureSerializer):

    ancestors = serializers.SerializerMethodField()
    timeseries = TimeseriesSerialazer()

    class Meta:
        model = City
        geo_field = "point"
        fields = (
            "uuid",
            "name",
            "name_ru",
            "is_small",
            "sort_rank",
            "timeseries",
            "has_any_timeseries",
            "ancestors",
        )

    def get_ancestors(self, obj):
        return [
            {
                "uuid": None,
                "name": getattr(obj.country, 'name', None),
                "name_ru": getattr(obj.country, 'name_ru', None),
                "obj": "country",
            },
        ]


class PointSerializer(ApiFeatureSerializer):

    ancestors = serializers.SerializerMethodField()
    timeseries = TimeseriesSerialazer()

    class Meta:
        model = Source
        geo_field = "point"
        fields = (
            "uuid",
            "name",
            "name_ru",
            "timeseries",
            "has_any_timeseries",
            "ancestors",
        )

    def get_ancestors(self, obj):
        city_properties = CitySerializer(obj.city).data["properties"]
        del city_properties["timeseries"]
        del city_properties["has_any_timeseries"]
        country_properties = city_properties["ancestors"][0]
        del city_properties["ancestors"]
        return [
            city_properties,
            country_properties,
        ]
