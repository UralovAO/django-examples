from django.contrib.gis.db.models import GeometryField
from django.db import models
from django_uidfield.fields import UIDField  # type: ignore
from django_uidfield.models import UIDModel  # type: ignore

from core.models import FeatureMixin, HarvesterModelMixin, \
    TranslatableModelMixin


class GeoCatalog(UIDModel):

    class Kind(models.IntegerChoices):
        COUNTRY = 1, 'COUNTRY'

    uuid = UIDField(prefix="gc_", max_length=30)
    # polygon = PolygonField(unique=True, null=True)
    geometry = GeometryField(null=True)
    code = models.CharField(default=False, null=True, max_length=100)
    name = models.CharField(default=False, null=False, max_length=200)
    name_ru = models.CharField(default=False, null=True, max_length=200)
    kind = models.CharField(choices=Kind.choices, max_length=100)


class City(UIDModel, FeatureMixin, TranslatableModelMixin,
           HarvesterModelMixin):

    uuid = UIDField(prefix="City_", max_length=30)
    is_small = models.BooleanField(default=False)
    sort_rank = models.IntegerField(null=True)

    country = models.ForeignKey(
        GeoCatalog,
        null=True,
        on_delete=models.PROTECT,
    )

    def get_api_type(self):
        return 'city'

    def __str__(self):
        return f'City({self.name}, {self.point})'


class Source(UIDModel, FeatureMixin, TranslatableModelMixin,
             HarvesterModelMixin):
    uuid = UIDField(prefix="Source_", max_length=30)
    city = models.ForeignKey(
        City,
        null=False,
        on_delete=models.PROTECT,
    )

    def get_api_type(self):
        return 'source'
